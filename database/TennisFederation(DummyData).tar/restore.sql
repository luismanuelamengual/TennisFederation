--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public."user" DROP CONSTRAINT user_usertypeid_fkey;
ALTER TABLE ONLY public."user" DROP CONSTRAINT user_provinceid_fkey;
ALTER TABLE ONLY public."user" DROP CONSTRAINT user_countryid_fkey;
ALTER TABLE ONLY public."user" DROP CONSTRAINT user_clubid_fkey;
ALTER TABLE ONLY public.tournamentzoneuser DROP CONSTRAINT tournamentzoneuser_userbid_fkey;
ALTER TABLE ONLY public.tournamentzoneuser DROP CONSTRAINT tournamentzoneuser_useraid_fkey;
ALTER TABLE ONLY public.tournamentzoneuser DROP CONSTRAINT tournamentzoneuser_tournamentzoneid_fkey;
ALTER TABLE ONLY public.tournamentzone DROP CONSTRAINT tournamentzone_tournamentphaseid_fkey;
ALTER TABLE ONLY public.tournamentphase DROP CONSTRAINT tournamentphase_tournamentphaseid_fkey;
ALTER TABLE ONLY public.tournamentphase DROP CONSTRAINT tournamentphase_tournamentid_fkey;
ALTER TABLE ONLY public.tournamentinscription DROP CONSTRAINT tournamentinscription_userbid_fkey;
ALTER TABLE ONLY public.tournamentinscription DROP CONSTRAINT tournamentinscription_useraid_fkey;
ALTER TABLE ONLY public.tournamentinscription DROP CONSTRAINT tournamentinscription_categoryid_fkey;
ALTER TABLE ONLY public.tournamentcategory DROP CONSTRAINT tournamentcategory_tournamentid_fkey;
ALTER TABLE ONLY public.tournamentcategory DROP CONSTRAINT tournamentcategory_categoryid_fkey;
ALTER TABLE ONLY public.tournament DROP CONSTRAINT tournament_tournamentstateid_fkey;
ALTER TABLE ONLY public.tournament DROP CONSTRAINT tournament_provinceid_fkey;
ALTER TABLE ONLY public.tournament DROP CONSTRAINT tournament_organizerid_fkey;
ALTER TABLE ONLY public.tournament DROP CONSTRAINT tournament_countryid_fkey;
ALTER TABLE ONLY public.tournament DROP CONSTRAINT tournament_clubid_fkey;
ALTER TABLE ONLY public.ranking DROP CONSTRAINT ranking_userid_fkey;
ALTER TABLE ONLY public.ranking DROP CONSTRAINT ranking_tournamentid_fkey;
ALTER TABLE ONLY public.notification DROP CONSTRAINT notification_userid_fkey;
ALTER TABLE ONLY public.notification DROP CONSTRAINT notification_provinceid_fkey;
ALTER TABLE ONLY public.notification DROP CONSTRAINT notification_creationuserid_fkey;
ALTER TABLE ONLY public.notification DROP CONSTRAINT notification_countryid_fkey;
ALTER TABLE ONLY public.notification DROP CONSTRAINT notification_clubid_fkey;
ALTER TABLE ONLY public.match DROP CONSTRAINT match_userdid_fkey;
ALTER TABLE ONLY public.match DROP CONSTRAINT match_usercid_fkey;
ALTER TABLE ONLY public.match DROP CONSTRAINT match_userbid_fkey;
ALTER TABLE ONLY public.match DROP CONSTRAINT match_useraid_fkey;
ALTER TABLE ONLY public.match DROP CONSTRAINT match_tournamentzoneid_fkey;
ALTER TABLE ONLY public.match DROP CONSTRAINT match_tournamentphaseid_fkey;
ALTER TABLE ONLY public.match DROP CONSTRAINT match_tournamentid_fkey;
ALTER TABLE ONLY public.usertype DROP CONSTRAINT usertype_pkey;
ALTER TABLE ONLY public."user" DROP CONSTRAINT user_username_key;
ALTER TABLE ONLY public."user" DROP CONSTRAINT user_pkey;
ALTER TABLE ONLY public.tournamentzone DROP CONSTRAINT tournamentzone_pkey;
ALTER TABLE ONLY public.tournamentstate DROP CONSTRAINT tournamentstate_pkey;
ALTER TABLE ONLY public.tournamentphase DROP CONSTRAINT tournamentphase_pkey;
ALTER TABLE ONLY public.tournamentinscription DROP CONSTRAINT tournamentinscription_pkey;
ALTER TABLE ONLY public.tournament DROP CONSTRAINT tournament_pkey;
ALTER TABLE ONLY public.province DROP CONSTRAINT province_pkey;
ALTER TABLE ONLY public.notification DROP CONSTRAINT notification_pkey;
ALTER TABLE ONLY public.match DROP CONSTRAINT match_pkey;
ALTER TABLE ONLY public.country DROP CONSTRAINT country_pkey;
ALTER TABLE ONLY public.club DROP CONSTRAINT club_pkey;
ALTER TABLE ONLY public.category DROP CONSTRAINT category_pkey;
ALTER TABLE public.usertype ALTER COLUMN usertypeid DROP DEFAULT;
ALTER TABLE public."user" ALTER COLUMN userid DROP DEFAULT;
ALTER TABLE public.tournamentzone ALTER COLUMN tournamentzoneid DROP DEFAULT;
ALTER TABLE public.tournamentstate ALTER COLUMN tournamentstateid DROP DEFAULT;
ALTER TABLE public.tournamentphase ALTER COLUMN tournamentphaseid DROP DEFAULT;
ALTER TABLE public.tournament ALTER COLUMN tournamentid DROP DEFAULT;
ALTER TABLE public.province ALTER COLUMN provinceid DROP DEFAULT;
ALTER TABLE public.notification ALTER COLUMN notificationid DROP DEFAULT;
ALTER TABLE public.match ALTER COLUMN matchid DROP DEFAULT;
ALTER TABLE public.country ALTER COLUMN countryid DROP DEFAULT;
ALTER TABLE public.club ALTER COLUMN clubid DROP DEFAULT;
ALTER TABLE public.category ALTER COLUMN categoryid DROP DEFAULT;
DROP SEQUENCE public.usertype_usertypeid_seq;
DROP TABLE public.usertype;
DROP SEQUENCE public.user_userid_seq;
DROP TABLE public."user";
DROP TABLE public.tournamentzoneuser;
DROP SEQUENCE public.tournamentzone_tournamentzoneid_seq;
DROP TABLE public.tournamentzone;
DROP SEQUENCE public.tournamentstate_tournamentstateid_seq;
DROP TABLE public.tournamentstate;
DROP SEQUENCE public.tournamentphase_tournamentphaseid_seq;
DROP TABLE public.tournamentphase;
DROP TABLE public.tournamentinscription;
DROP TABLE public.tournamentcategory;
DROP SEQUENCE public.tournament_tournamentid_seq;
DROP TABLE public.tournament;
DROP TABLE public.ranking;
DROP SEQUENCE public.province_provinceid_seq;
DROP TABLE public.province;
DROP SEQUENCE public.notification_notificationid_seq;
DROP TABLE public.notification;
DROP SEQUENCE public.match_matchid_seq;
DROP TABLE public.match;
DROP SEQUENCE public.country_countryid_seq;
DROP TABLE public.country;
DROP SEQUENCE public.club_clubid_seq;
DROP TABLE public.club;
DROP SEQUENCE public.category_categoryid_seq;
DROP TABLE public.category;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: category; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE category (
    categoryid integer NOT NULL,
    description text NOT NULL,
    matchtype integer NOT NULL
);


ALTER TABLE public.category OWNER TO postgres;

--
-- Name: category_categoryid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE category_categoryid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_categoryid_seq OWNER TO postgres;

--
-- Name: category_categoryid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE category_categoryid_seq OWNED BY category.categoryid;


--
-- Name: club; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE club (
    clubid integer NOT NULL,
    description text NOT NULL,
    latitude real,
    longitude real,
    address text,
    contactvia1 text,
    contactvia2 text
);


ALTER TABLE public.club OWNER TO postgres;

--
-- Name: club_clubid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE club_clubid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.club_clubid_seq OWNER TO postgres;

--
-- Name: club_clubid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE club_clubid_seq OWNED BY club.clubid;


--
-- Name: country; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE country (
    countryid integer NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.country OWNER TO postgres;

--
-- Name: country_countryid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE country_countryid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.country_countryid_seq OWNER TO postgres;

--
-- Name: country_countryid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE country_countryid_seq OWNED BY country.countryid;


--
-- Name: match; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE match (
    matchid integer NOT NULL,
    matchtype integer NOT NULL,
    useraid integer,
    userbid integer,
    usercid integer,
    userdid integer,
    tournamentid integer NOT NULL,
    tournamentphaseid integer NOT NULL,
    tournamentzoneid integer,
    date timestamp without time zone,
    resultdetail text,
    result integer
);


ALTER TABLE public.match OWNER TO postgres;

--
-- Name: match_matchid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE match_matchid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.match_matchid_seq OWNER TO postgres;

--
-- Name: match_matchid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE match_matchid_seq OWNED BY match.matchid;


--
-- Name: notification; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE notification (
    notificationid integer NOT NULL,
    countryid integer,
    provinceid integer,
    clubid integer,
    userid integer,
    expirationdate timestamp without time zone,
    message text,
    creationuserid integer,
    creationdate timestamp without time zone
);


ALTER TABLE public.notification OWNER TO postgres;

--
-- Name: notification_notificationid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE notification_notificationid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_notificationid_seq OWNER TO postgres;

--
-- Name: notification_notificationid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE notification_notificationid_seq OWNED BY notification.notificationid;


--
-- Name: province; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE province (
    provinceid integer NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.province OWNER TO postgres;

--
-- Name: province_provinceid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE province_provinceid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.province_provinceid_seq OWNER TO postgres;

--
-- Name: province_provinceid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE province_provinceid_seq OWNED BY province.provinceid;


--
-- Name: ranking; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE ranking (
    userid integer NOT NULL,
    points integer NOT NULL,
    tournamentid integer,
    date timestamp without time zone,
    expirationdate timestamp without time zone
);


ALTER TABLE public.ranking OWNER TO postgres;

--
-- Name: tournament; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tournament (
    tournamentid integer NOT NULL,
    description text NOT NULL,
    clubid integer NOT NULL,
    startdate timestamp without time zone NOT NULL,
    inscriptionsdate timestamp without time zone,
    countryid integer,
    provinceid integer,
    tournamentstateid integer NOT NULL,
    organizerid integer
);


ALTER TABLE public.tournament OWNER TO postgres;

--
-- Name: tournament_tournamentid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tournament_tournamentid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tournament_tournamentid_seq OWNER TO postgres;

--
-- Name: tournament_tournamentid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tournament_tournamentid_seq OWNED BY tournament.tournamentid;


--
-- Name: tournamentcategory; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tournamentcategory (
    tournamentid integer NOT NULL,
    categoryid integer NOT NULL
);


ALTER TABLE public.tournamentcategory OWNER TO postgres;

--
-- Name: tournamentinscription; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tournamentinscription (
    tournamentid integer NOT NULL,
    useraid integer NOT NULL,
    userbid integer NOT NULL,
    categoryid integer NOT NULL
);


ALTER TABLE public.tournamentinscription OWNER TO postgres;

--
-- Name: tournamentphase; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tournamentphase (
    tournamentphaseid integer NOT NULL,
    tournamentid integer NOT NULL,
    description text NOT NULL,
    "order" integer
);


ALTER TABLE public.tournamentphase OWNER TO postgres;

--
-- Name: tournamentphase_tournamentphaseid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tournamentphase_tournamentphaseid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tournamentphase_tournamentphaseid_seq OWNER TO postgres;

--
-- Name: tournamentphase_tournamentphaseid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tournamentphase_tournamentphaseid_seq OWNED BY tournamentphase.tournamentphaseid;


--
-- Name: tournamentstate; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tournamentstate (
    tournamentstateid integer NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.tournamentstate OWNER TO postgres;

--
-- Name: tournamentstate_tournamentstateid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tournamentstate_tournamentstateid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tournamentstate_tournamentstateid_seq OWNER TO postgres;

--
-- Name: tournamentstate_tournamentstateid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tournamentstate_tournamentstateid_seq OWNED BY tournamentstate.tournamentstateid;


--
-- Name: tournamentzone; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tournamentzone (
    tournamentzoneid integer NOT NULL,
    description text NOT NULL,
    tournamentphaseid integer NOT NULL
);


ALTER TABLE public.tournamentzone OWNER TO postgres;

--
-- Name: tournamentzone_tournamentzoneid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tournamentzone_tournamentzoneid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tournamentzone_tournamentzoneid_seq OWNER TO postgres;

--
-- Name: tournamentzone_tournamentzoneid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tournamentzone_tournamentzoneid_seq OWNED BY tournamentzone.tournamentzoneid;


--
-- Name: tournamentzoneuser; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tournamentzoneuser (
    tournamentzoneid integer NOT NULL,
    useraid integer NOT NULL,
    userbid integer
);


ALTER TABLE public.tournamentzoneuser OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "user" (
    userid integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    usertypeid integer NOT NULL,
    firstname text NOT NULL,
    lastname text NOT NULL,
    birthdate timestamp without time zone,
    address text,
    contactvia1 text,
    contactvia2 text,
    contactvia3 text,
    email text,
    clubid integer,
    data text,
    documentnumber text,
    countryid integer,
    provinceid integer,
    active boolean NOT NULL
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: user_userid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE user_userid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_userid_seq OWNER TO postgres;

--
-- Name: user_userid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE user_userid_seq OWNED BY "user".userid;


--
-- Name: usertype; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE usertype (
    usertypeid integer NOT NULL,
    description text
);


ALTER TABLE public.usertype OWNER TO postgres;

--
-- Name: usertype_usertypeid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE usertype_usertypeid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usertype_usertypeid_seq OWNER TO postgres;

--
-- Name: usertype_usertypeid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE usertype_usertypeid_seq OWNED BY usertype.usertypeid;


--
-- Name: categoryid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY category ALTER COLUMN categoryid SET DEFAULT nextval('category_categoryid_seq'::regclass);


--
-- Name: clubid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY club ALTER COLUMN clubid SET DEFAULT nextval('club_clubid_seq'::regclass);


--
-- Name: countryid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY country ALTER COLUMN countryid SET DEFAULT nextval('country_countryid_seq'::regclass);


--
-- Name: matchid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY match ALTER COLUMN matchid SET DEFAULT nextval('match_matchid_seq'::regclass);


--
-- Name: notificationid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY notification ALTER COLUMN notificationid SET DEFAULT nextval('notification_notificationid_seq'::regclass);


--
-- Name: provinceid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY province ALTER COLUMN provinceid SET DEFAULT nextval('province_provinceid_seq'::regclass);


--
-- Name: tournamentid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournament ALTER COLUMN tournamentid SET DEFAULT nextval('tournament_tournamentid_seq'::regclass);


--
-- Name: tournamentphaseid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournamentphase ALTER COLUMN tournamentphaseid SET DEFAULT nextval('tournamentphase_tournamentphaseid_seq'::regclass);


--
-- Name: tournamentstateid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournamentstate ALTER COLUMN tournamentstateid SET DEFAULT nextval('tournamentstate_tournamentstateid_seq'::regclass);


--
-- Name: tournamentzoneid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournamentzone ALTER COLUMN tournamentzoneid SET DEFAULT nextval('tournamentzone_tournamentzoneid_seq'::regclass);


--
-- Name: userid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "user" ALTER COLUMN userid SET DEFAULT nextval('user_userid_seq'::regclass);


--
-- Name: usertypeid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usertype ALTER COLUMN usertypeid SET DEFAULT nextval('usertype_usertypeid_seq'::regclass);


--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY category (categoryid, description, matchtype) FROM stdin;
\.
COPY category (categoryid, description, matchtype) FROM '$$PATH$$/2092.dat';

--
-- Name: category_categoryid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('category_categoryid_seq', 11, true);


--
-- Data for Name: club; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY club (clubid, description, latitude, longitude, address, contactvia1, contactvia2) FROM stdin;
\.
COPY club (clubid, description, latitude, longitude, address, contactvia1, contactvia2) FROM '$$PATH$$/2094.dat';

--
-- Name: club_clubid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('club_clubid_seq', 5, true);


--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY country (countryid, description) FROM stdin;
\.
COPY country (countryid, description) FROM '$$PATH$$/2096.dat';

--
-- Name: country_countryid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('country_countryid_seq', 4, true);


--
-- Data for Name: match; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY match (matchid, matchtype, useraid, userbid, usercid, userdid, tournamentid, tournamentphaseid, tournamentzoneid, date, resultdetail, result) FROM stdin;
\.
COPY match (matchid, matchtype, useraid, userbid, usercid, userdid, tournamentid, tournamentphaseid, tournamentzoneid, date, resultdetail, result) FROM '$$PATH$$/2115.dat';

--
-- Name: match_matchid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('match_matchid_seq', 1, false);


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY notification (notificationid, countryid, provinceid, clubid, userid, expirationdate, message, creationuserid, creationdate) FROM stdin;
\.
COPY notification (notificationid, countryid, provinceid, clubid, userid, expirationdate, message, creationuserid, creationdate) FROM '$$PATH$$/2117.dat';

--
-- Name: notification_notificationid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('notification_notificationid_seq', 1, false);


--
-- Data for Name: province; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY province (provinceid, description) FROM stdin;
\.
COPY province (provinceid, description) FROM '$$PATH$$/2098.dat';

--
-- Name: province_provinceid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('province_provinceid_seq', 4, true);


--
-- Data for Name: ranking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ranking (userid, points, tournamentid, date, expirationdate) FROM stdin;
\.
COPY ranking (userid, points, tournamentid, date, expirationdate) FROM '$$PATH$$/2113.dat';

--
-- Data for Name: tournament; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tournament (tournamentid, description, clubid, startdate, inscriptionsdate, countryid, provinceid, tournamentstateid, organizerid) FROM stdin;
\.
COPY tournament (tournamentid, description, clubid, startdate, inscriptionsdate, countryid, provinceid, tournamentstateid, organizerid) FROM '$$PATH$$/2100.dat';

--
-- Name: tournament_tournamentid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tournament_tournamentid_seq', 1, false);


--
-- Data for Name: tournamentcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tournamentcategory (tournamentid, categoryid) FROM stdin;
\.
COPY tournamentcategory (tournamentid, categoryid) FROM '$$PATH$$/2102.dat';

--
-- Data for Name: tournamentinscription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tournamentinscription (tournamentid, useraid, userbid, categoryid) FROM stdin;
\.
COPY tournamentinscription (tournamentid, useraid, userbid, categoryid) FROM '$$PATH$$/2118.dat';

--
-- Data for Name: tournamentphase; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tournamentphase (tournamentphaseid, tournamentid, description, "order") FROM stdin;
\.
COPY tournamentphase (tournamentphaseid, tournamentid, description, "order") FROM '$$PATH$$/2103.dat';

--
-- Name: tournamentphase_tournamentphaseid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tournamentphase_tournamentphaseid_seq', 1, false);


--
-- Data for Name: tournamentstate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tournamentstate (tournamentstateid, description) FROM stdin;
\.
COPY tournamentstate (tournamentstateid, description) FROM '$$PATH$$/2105.dat';

--
-- Name: tournamentstate_tournamentstateid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tournamentstate_tournamentstateid_seq', 3, true);


--
-- Data for Name: tournamentzone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tournamentzone (tournamentzoneid, description, tournamentphaseid) FROM stdin;
\.
COPY tournamentzone (tournamentzoneid, description, tournamentphaseid) FROM '$$PATH$$/2107.dat';

--
-- Name: tournamentzone_tournamentzoneid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tournamentzone_tournamentzoneid_seq', 1, false);


--
-- Data for Name: tournamentzoneuser; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tournamentzoneuser (tournamentzoneid, useraid, userbid) FROM stdin;
\.
COPY tournamentzoneuser (tournamentzoneid, useraid, userbid) FROM '$$PATH$$/2119.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "user" (userid, username, password, usertypeid, firstname, lastname, birthdate, address, contactvia1, contactvia2, contactvia3, email, clubid, data, documentnumber, countryid, provinceid, active) FROM stdin;
\.
COPY "user" (userid, username, password, usertypeid, firstname, lastname, birthdate, address, contactvia1, contactvia2, contactvia3, email, clubid, data, documentnumber, countryid, provinceid, active) FROM '$$PATH$$/2112.dat';

--
-- Name: user_userid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('user_userid_seq', 4, true);


--
-- Data for Name: usertype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY usertype (usertypeid, description) FROM stdin;
\.
COPY usertype (usertypeid, description) FROM '$$PATH$$/2110.dat';

--
-- Name: usertype_usertypeid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('usertype_usertypeid_seq', 3, true);


--
-- Name: category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY category
    ADD CONSTRAINT category_pkey PRIMARY KEY (categoryid);


--
-- Name: club_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY club
    ADD CONSTRAINT club_pkey PRIMARY KEY (clubid);


--
-- Name: country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY country
    ADD CONSTRAINT country_pkey PRIMARY KEY (countryid);


--
-- Name: match_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY match
    ADD CONSTRAINT match_pkey PRIMARY KEY (matchid);


--
-- Name: notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (notificationid);


--
-- Name: province_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY province
    ADD CONSTRAINT province_pkey PRIMARY KEY (provinceid);


--
-- Name: tournament_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tournament
    ADD CONSTRAINT tournament_pkey PRIMARY KEY (tournamentid);


--
-- Name: tournamentinscription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tournamentinscription
    ADD CONSTRAINT tournamentinscription_pkey PRIMARY KEY (tournamentid);


--
-- Name: tournamentphase_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tournamentphase
    ADD CONSTRAINT tournamentphase_pkey PRIMARY KEY (tournamentphaseid);


--
-- Name: tournamentstate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tournamentstate
    ADD CONSTRAINT tournamentstate_pkey PRIMARY KEY (tournamentstateid);


--
-- Name: tournamentzone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tournamentzone
    ADD CONSTRAINT tournamentzone_pkey PRIMARY KEY (tournamentzoneid);


--
-- Name: user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (userid);


--
-- Name: user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_username_key UNIQUE (username);


--
-- Name: usertype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY usertype
    ADD CONSTRAINT usertype_pkey PRIMARY KEY (usertypeid);


--
-- Name: match_tournamentid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY match
    ADD CONSTRAINT match_tournamentid_fkey FOREIGN KEY (tournamentid) REFERENCES tournament(tournamentid);


--
-- Name: match_tournamentphaseid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY match
    ADD CONSTRAINT match_tournamentphaseid_fkey FOREIGN KEY (tournamentphaseid) REFERENCES tournamentphase(tournamentphaseid);


--
-- Name: match_tournamentzoneid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY match
    ADD CONSTRAINT match_tournamentzoneid_fkey FOREIGN KEY (tournamentzoneid) REFERENCES tournamentzone(tournamentzoneid);


--
-- Name: match_useraid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY match
    ADD CONSTRAINT match_useraid_fkey FOREIGN KEY (useraid) REFERENCES "user"(userid);


--
-- Name: match_userbid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY match
    ADD CONSTRAINT match_userbid_fkey FOREIGN KEY (userbid) REFERENCES "user"(userid);


--
-- Name: match_usercid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY match
    ADD CONSTRAINT match_usercid_fkey FOREIGN KEY (usercid) REFERENCES "user"(userid);


--
-- Name: match_userdid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY match
    ADD CONSTRAINT match_userdid_fkey FOREIGN KEY (userdid) REFERENCES "user"(userid);


--
-- Name: notification_clubid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY notification
    ADD CONSTRAINT notification_clubid_fkey FOREIGN KEY (clubid) REFERENCES club(clubid);


--
-- Name: notification_countryid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY notification
    ADD CONSTRAINT notification_countryid_fkey FOREIGN KEY (countryid) REFERENCES country(countryid);


--
-- Name: notification_creationuserid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY notification
    ADD CONSTRAINT notification_creationuserid_fkey FOREIGN KEY (creationuserid) REFERENCES "user"(userid);


--
-- Name: notification_provinceid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY notification
    ADD CONSTRAINT notification_provinceid_fkey FOREIGN KEY (provinceid) REFERENCES province(provinceid);


--
-- Name: notification_userid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY notification
    ADD CONSTRAINT notification_userid_fkey FOREIGN KEY (userid) REFERENCES "user"(userid);


--
-- Name: ranking_tournamentid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ranking
    ADD CONSTRAINT ranking_tournamentid_fkey FOREIGN KEY (tournamentid) REFERENCES tournament(tournamentid);


--
-- Name: ranking_userid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ranking
    ADD CONSTRAINT ranking_userid_fkey FOREIGN KEY (userid) REFERENCES "user"(userid);


--
-- Name: tournament_clubid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournament
    ADD CONSTRAINT tournament_clubid_fkey FOREIGN KEY (clubid) REFERENCES club(clubid);


--
-- Name: tournament_countryid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournament
    ADD CONSTRAINT tournament_countryid_fkey FOREIGN KEY (countryid) REFERENCES country(countryid);


--
-- Name: tournament_organizerid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournament
    ADD CONSTRAINT tournament_organizerid_fkey FOREIGN KEY (organizerid) REFERENCES "user"(userid);


--
-- Name: tournament_provinceid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournament
    ADD CONSTRAINT tournament_provinceid_fkey FOREIGN KEY (provinceid) REFERENCES province(provinceid);


--
-- Name: tournament_tournamentstateid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournament
    ADD CONSTRAINT tournament_tournamentstateid_fkey FOREIGN KEY (tournamentstateid) REFERENCES tournamentstate(tournamentstateid);


--
-- Name: tournamentcategory_categoryid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournamentcategory
    ADD CONSTRAINT tournamentcategory_categoryid_fkey FOREIGN KEY (categoryid) REFERENCES category(categoryid);


--
-- Name: tournamentcategory_tournamentid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournamentcategory
    ADD CONSTRAINT tournamentcategory_tournamentid_fkey FOREIGN KEY (tournamentid) REFERENCES tournament(tournamentid);


--
-- Name: tournamentinscription_categoryid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournamentinscription
    ADD CONSTRAINT tournamentinscription_categoryid_fkey FOREIGN KEY (categoryid) REFERENCES category(categoryid);


--
-- Name: tournamentinscription_useraid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournamentinscription
    ADD CONSTRAINT tournamentinscription_useraid_fkey FOREIGN KEY (useraid) REFERENCES "user"(userid);


--
-- Name: tournamentinscription_userbid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournamentinscription
    ADD CONSTRAINT tournamentinscription_userbid_fkey FOREIGN KEY (userbid) REFERENCES "user"(userid);


--
-- Name: tournamentphase_tournamentid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournamentphase
    ADD CONSTRAINT tournamentphase_tournamentid_fkey FOREIGN KEY (tournamentid) REFERENCES tournament(tournamentid);


--
-- Name: tournamentphase_tournamentphaseid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournamentphase
    ADD CONSTRAINT tournamentphase_tournamentphaseid_fkey FOREIGN KEY (tournamentphaseid) REFERENCES tournamentphase(tournamentphaseid);


--
-- Name: tournamentzone_tournamentphaseid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournamentzone
    ADD CONSTRAINT tournamentzone_tournamentphaseid_fkey FOREIGN KEY (tournamentphaseid) REFERENCES tournamentphase(tournamentphaseid);


--
-- Name: tournamentzoneuser_tournamentzoneid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournamentzoneuser
    ADD CONSTRAINT tournamentzoneuser_tournamentzoneid_fkey FOREIGN KEY (tournamentzoneid) REFERENCES tournamentzone(tournamentzoneid);


--
-- Name: tournamentzoneuser_useraid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournamentzoneuser
    ADD CONSTRAINT tournamentzoneuser_useraid_fkey FOREIGN KEY (useraid) REFERENCES "user"(userid);


--
-- Name: tournamentzoneuser_userbid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tournamentzoneuser
    ADD CONSTRAINT tournamentzoneuser_userbid_fkey FOREIGN KEY (userbid) REFERENCES "user"(userid);


--
-- Name: user_clubid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_clubid_fkey FOREIGN KEY (clubid) REFERENCES club(clubid);


--
-- Name: user_countryid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_countryid_fkey FOREIGN KEY (countryid) REFERENCES country(countryid);


--
-- Name: user_provinceid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_provinceid_fkey FOREIGN KEY (provinceid) REFERENCES province(provinceid);


--
-- Name: user_usertypeid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_usertypeid_fkey FOREIGN KEY (usertypeid) REFERENCES usertype(usertypeid);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

